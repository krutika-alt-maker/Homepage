import React from 'react'

export const Profile = () => {
    return (
        <div>
            This is an NewLetter component 
        </div>
    )
}
