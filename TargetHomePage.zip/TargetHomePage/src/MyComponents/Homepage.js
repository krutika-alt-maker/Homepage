import React from 'react'
import meme1 from '../targetcarousel1.png';
import meme2 from '../targetcarousel2.png';
import meme3 from '../targetcarousel3.png';
import meme4 from '../targetcarousel4.png';
import meme5 from '../targetcarousel5.png';
import boot from '../cloud.jpg';
import boot1 from '../cyber.jpg';
//import url from '../bootstrap-illustration.png';
export const Homepage = () => {
    //const url = 'https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.tutorialrepublic.com%2Ftwitter-bootstrap-tutorial%2F&psig=AOvVaw2i27xmfbOGu5TGH9vWmWz0&ust=1627062895295000&source=images&cd=vfe&ved=0CAcQjRxqFwoTCKDZ45mg9_ECFQAAAAAdAAAAABAD';
    const mystyle = {
        color: "black",
        backgroundColor: "white",
        padding: "10px",
        fontFamily: "Arial",
        float: 'left'
    };
    const body = {
        backgroundColor: "white",
        color: "black",
        padding: "40px",
        fontFamily: " Rockwell",
        textAlign: 'center'

    };

    const divStyle = {
        backgroundColor: "black",
        color: "white",
        padding: "40px",
        fontFamily: " Arial",
        textAlign: 'left'
    };

    return (
        <>
            <div id="carouselExampleControls" className="carousel slide" data-bs-ride="carousel">
                <div className="carousel-inner">
                    <div className="carousel-item active">
                        <a href="https://india.target.com/about-us/our-foundation"> <img src={meme5} className="d-block w-100" alt="..." style={{ height: 500, width: 500 }} /></a>
                    </div>
                    <div className="carousel-item">
                        <a href="https://india.target.com/about-us/our-foundation"> <img src={meme4} className="d-block w-100" alt="..." style={{ height: 500, width: 500 }} /></a>
                    </div>
                    <div className="carousel-item">
                        <a href="https://india.target.com/about-us/our-foundation">  <img src={meme2} className="d-block w-100" alt="..." style={{ height: 500, width: 500 }} /></a>
                    </div>
                    <div className="carousel-item">
                        <a href="https://india.target.com/about-us/our-foundation">  <img src={meme1} className="d-block w-100" alt="..." style={{ height: 500, width: 500 }} /></a>
                    </div>
                    <div className="carousel-item">
                        <a href="https://india.target.com/about-us/our-foundation">  <img src={meme3} className="d-block w-100" alt="..." style={{ height: 500, width: 500 }} /></a>
                    </div>

                </div>
                <button className="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
                    <span className="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span className="visually-hidden">Previous</span>
                </button>
                <button className="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
                    <span className="carousel-control-next-icon" aria-hidden="true"></span>
                    <span className="visually-hidden">Next</span>
                </button>
            </div>
            <div style={body}>
                <h4 >Pick your path Whether it's a career in Design, Finance or Analytics, there are plenty of opportunities.But to cope
                    with every evolving paths to be updated is more become a part of life
                </h4>
               
            </div>  
            
            <div>
            <h4 style={body} ><b>
                “We are what we repeatedly do. Excellence then, is not an act, but a habit.” -Aristotle, philosophe</b></h4>
            </div>
            


        </>


    )
}
