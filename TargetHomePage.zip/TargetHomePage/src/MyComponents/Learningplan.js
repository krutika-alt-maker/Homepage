import React from 'react'

export const Learningplan = () => {
    return (
        <div>
            This is an NewLetter component 
        </div>
    )
}
