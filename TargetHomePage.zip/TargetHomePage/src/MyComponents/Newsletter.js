import React from 'react'

export const Newsletter = () => {
    return (
        <div>
            This is an NewLetter component 
        </div>
    )
}
