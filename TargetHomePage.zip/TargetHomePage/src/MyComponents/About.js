import React from 'react'
import logos from '../about.png';

export const About = () => {

const s={
  backgroundColor:'white',
  color:'black',
  font:'RockWell'
};
const s1={
  backgroundColor:'red',
  color:'black',
  font:'RockWell'
};
  return (
    <>
      <img src={logos} alt="About Target Organization" class="center" style={{ width: 2500, height: 500 }} />
      <div style={s}>
        <h3 >Our Purpose</h3>
        <h4> To help all families discover the joy of everyday life.
</h4>
        <p>
                   We believe that family is how one chooses to define it, and for each family that shops with us, we work towards being a part of their life moments and enabling them to experience joy. 
                   <br/>
                   In short, our purpose holds the promise of surprises, fun, ease and inspiration at every turn. 
                   <br/>
                   We do this no matter when, where or how our guests shop.

          That quest to bring joy is at the center of every business decision we make. It gets our 350,000+ team members excited to come to work each day. And we bring it to life in so many ways.

        </p><br /><br />

        <h2>Our Values</h2>
        <p>
          As team members of Target in India, our work is defined by the values that our brand stands for. They help us bring our best selves to work every day.
        </p>
      </div>

      <h5 styel={s1}>What defines us
Our team members are united by Target’s culture – fun, diverse, inclusive and with endless opportunities for growth. At Target in India, our culture can clearly be seen in action in four key areas.

</h5>
    </>


  )
}
