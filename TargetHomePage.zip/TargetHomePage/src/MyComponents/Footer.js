import React from 'react'
import target from "../target.png";

export const Footer = () => {
    const mystyle3 = {
        color: "white",
        backgroundColor: "black",
        padding: "10px",
        fontFamily: "Arial",
        float: 'center'
    };
    return (
        <footer >
            <div>
                <p className="text-center" style={mystyle3}>
                    <img src={target} style={{ height: 40, width: 40 }} alt=".." />

                    Target Brands, Inc. Target and the Bullseye Design are registered trademarks of Target Brands, Inc. &copy; Target.com

                </p>
            </div>
            

        </footer>
    )
}
