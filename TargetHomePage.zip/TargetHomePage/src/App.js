import './App.css';
import Header from "./MyComponents/Header";
import { Footer } from "./MyComponents/Footer";
import { About } from "./MyComponents/About";
import { Learningplan} from "./MyComponents/Learningplan";
import {Newsletter} from "./MyComponents/Newsletter";
import { Profile } from './MyComponents/Profile';
import { Homepage } from './MyComponents/Homepage';
import React from 'react';
import {
  BrowserRouter as Router,
  Switch,
  Route
} from "react-router-dom";

function App() {
  return (
    <> 
    <Router>
      <Header title="Target Schedule" exact path="/header" /> 
      <Switch>
       <Route exact path="/homepage">
         <Homepage/>
       </Route>
          <Route exact path="/about">
            <About />
          </Route> 
          <Route exact path="/learningplan">
            <Learningplan />
          </Route> 
          <Route exact path="/newsletter">
            <Newsletter />
          </Route> 
          <Route exact path="/profile">
            <Profile />
          </Route>
       </Switch> 
      <Footer />
    </Router>
    </>
  );
}

export default App;
